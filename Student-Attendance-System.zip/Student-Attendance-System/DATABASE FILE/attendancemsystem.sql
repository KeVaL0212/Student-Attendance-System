-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 13, 2023 at 11:34 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendancemsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

DROP TABLE IF EXISTS `tbladmin`;
CREATE TABLE IF NOT EXISTS `tbladmin` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `emailAddress` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`Id`, `firstName`, `lastName`, `emailAddress`, `password`) VALUES
(1, 'Admin', '', 'admin@mail.com', 'D00F5D5217896FB7FD601412CB890830');

-- --------------------------------------------------------

--
-- Table structure for table `tblattendance`
--

DROP TABLE IF EXISTS `tblattendance`;
CREATE TABLE IF NOT EXISTS `tblattendance` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `admissionNo` varchar(255) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `sessionTermId` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `dateTimeTaken` varchar(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=220 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblattendance`
--

INSERT INTO `tblattendance` (`Id`, `admissionNo`, `classId`, `classArmId`, `sessionTermId`, `status`, `dateTimeTaken`) VALUES
(162, 'ASDFLKJ', '1', '2', '1', '1', '2023-04-13'),
(163, 'HSKSDD', '1', '2', '1', '1', '2023-04-13'),
(164, 'JSLDKJ', '1', '2', '1', '1', '2023-04-13'),
(172, 'HSKDS9EE', '1', '4', '1', '1', '2023-04-13'),
(171, 'JKADA', '1', '4', '1', '0', '2023-04-13'),
(170, 'JSFSKDJ', '1', '4', '1', '1', '2023-04-13'),
(173, 'ASDFLKJ', '1', '2', '1', '1', '2023-04-13'),
(174, 'HSKSDD', '1', '2', '1', '1', '2023-04-13'),
(175, 'JSLDKJ', '1', '2', '1', '1', '2023-04-13'),
(176, 'JSFSKDJ', '1', '4', '1', '0', '2023-04-13'),
(177, 'JKADA', '1', '4', '1', '0', '2023-04-13'),
(178, 'HSKDS9EE', '1', '4', '1', '0', '2023-04-13'),
(179, 'ASDFLKJ', '1', '2', '1', '0', '2023-04-13'),
(180, 'HSKSDD', '1', '2', '1', '1', '2023-04-13'),
(181, 'JSLDKJ', '1', '2', '1', '1', '2023-04-13'),
(182, 'ASDFLKJ', '1', '2', '1', '0', '2023-04-13'),
(183, 'HSKSDD', '1', '2', '1', '0', '2023-04-13'),
(184, 'JSLDKJ', '1', '2', '1', '1', '2023-04-13'),
(185, 'ASDFLKJ', '1', '2', '1', '0', '2023-04-13'),
(186, 'HSKSDD', '1', '2', '1', '0', '2023-04-13'),
(187, 'JSLDKJ', '1', '2', '1', '0', '2023-04-13'),
(188, 'AMS110', '4', '6', '1', '1', '2023-04-13'),
(189, 'AMS133', '4', '6', '1', '0', '2023-04-13'),
(190, 'AMS135', '4', '6', '1', '0', '2023-04-13'),
(191, 'AMS144', '4', '6', '1', '1', '2023-04-13'),
(192, 'AMS148', '4', '6', '1', '0', '2021-10-07'),
(193, 'AMS151', '4', '6', '1', '1', '2021-10-07'),
(194, 'AMS159', '4', '6', '1', '1', '2021-10-07'),
(195, 'AMS161', '4', '6', '1', '1', '2021-10-07'),
(196, 'AMS110', '4', '6', '1', '1', '2022-06-06'),
(197, 'AMS133', '4', '6', '1', '0', '2022-06-06'),
(198, 'AMS135', '4', '6', '1', '0', '2022-06-06'),
(199, 'AMS144', '4', '6', '1', '1', '2022-06-06'),
(200, 'AMS148', '4', '6', '1', '0', '2022-06-06'),
(201, 'AMS151', '4', '6', '1', '1', '2022-06-06'),
(202, 'AMS159', '4', '6', '1', '1', '2022-06-06'),
(203, 'AMS161', '4', '6', '1', '1', '2022-06-06'),
(204, 'AMS005', '4', '6', '4', '1', '2023-04-13'),
(205, 'AMS007', '4', '6', '4', '1', '2023-04-13'),
(206, 'AMS011', '4', '6', '4', '1', '2023-04-13'),
(207, 'AMS012', '4', '6', '4', '0', '2023-04-13'),
(208, 'AMS015', '4', '6', '4', '1', '2023-04-13'),
(209, 'AMS017', '4', '6', '4', '1', '2023-04-13'),
(210, 'AMS019', '4', '6', '4', '0', '2023-04-13'),
(211, 'AMS021', '4', '6', '4', '0', '2023-04-13'),
(212, 'AMS110', '4', '6', '4', '0', '2023-04-13'),
(213, 'AMS133', '4', '6', '4', '0', '2023-04-13'),
(214, 'AMS135', '4', '6', '4', '0', '2023-04-13'),
(215, 'AMS144', '4', '6', '4', '0', '2023-04-13'),
(216, 'AMS148', '4', '6', '4', '0', '2023-04-13'),
(217, 'AMS151', '4', '6', '4', '0', '2023-04-13'),
(218, 'AMS159', '4', '6', '4', '0', '2023-04-13'),
(219, 'AMS161', '4', '6', '4', '0', '2023-04-13');

-- --------------------------------------------------------

--
-- Table structure for table `tblclass`
--

DROP TABLE IF EXISTS `tblclass`;
CREATE TABLE IF NOT EXISTS `tblclass` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `className` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclass`
--

INSERT INTO `tblclass` (`Id`, `className`) VALUES
(1, 'Seven'),
(3, 'Eight'),
(4, 'Nine'),
(5, 'One'),
(6, 'Two'),
(7, 'Three'),
(8, 'Four'),
(9, 'Five'),
(10, 'Six');

-- --------------------------------------------------------

--
-- Table structure for table `tblclassarms`
--

DROP TABLE IF EXISTS `tblclassarms`;
CREATE TABLE IF NOT EXISTS `tblclassarms` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `classId` varchar(10) NOT NULL,
  `classArmName` varchar(255) NOT NULL,
  `isAssigned` varchar(10) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclassarms`
--

INSERT INTO `tblclassarms` (`Id`, `classId`, `classArmName`, `isAssigned`) VALUES
(2, '1', 'A', '1'),
(4, '1', 'B', '1'),
(5, '3', 'A', '1'),
(6, '4', 'A', '1'),
(7, '3', 'B', '1'),
(8, '4', 'B', '1'),
(9, '10', 'A', '1'),
(10, '10', 'B', '1'),
(11, '9', 'A', '1'),
(12, '9', 'B', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tblclassteacher`
--

DROP TABLE IF EXISTS `tblclassteacher`;
CREATE TABLE IF NOT EXISTS `tblclassteacher` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `emailAddress` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phoneNo` varchar(50) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclassteacher`
--

INSERT INTO `tblclassteacher` (`Id`, `firstName`, `lastName`, `emailAddress`, `password`, `phoneNo`, `classId`, `classArmId`, `dateCreated`) VALUES
(1, 'Deepti', 'Sharma', 'teacher2@mail.com', '32250170a0dca92d53ec9624f336ca24', '09089898999', '1', '2', '2023-04-13'),
(4, 'Bhoomin', 'Patel', 'teacher3@gmail.com', '32250170a0dca92d53ec9624f336ca24', '09672002882', '2', '4', '2023-04-13'),
(5, 'Ayush', 'Sukani', 'teacher4@mail.com', '32250170a0dca92d53ec9624f336ca24', '7014560000', '3', '5', '2023-04-13'),
(6, 'Keval', 'Patel', 'teacher@mail.com', '32250170a0dca92d53ec9624f336ca24', '0100000030', '4', '6', '2023-04-13');

-- --------------------------------------------------------

--
-- Table structure for table `tblsessionterm`
--

DROP TABLE IF EXISTS `tblsessionterm`;
CREATE TABLE IF NOT EXISTS `tblsessionterm` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `sessionName` varchar(50) NOT NULL,
  `termId` varchar(50) NOT NULL,
  `isActive` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsessionterm`
--

INSERT INTO `tblsessionterm` (`Id`, `sessionName`, `termId`, `isActive`, `dateCreated`) VALUES
(1, '2021/2022', '1', '0', '2022-04-10'),
(3, '2021/2022', '2', '0', '2023-08-23'),
(4, '2022/2023', '3', '1', '2023-04-13');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

DROP TABLE IF EXISTS `tblstudents`;
CREATE TABLE IF NOT EXISTS `tblstudents` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `otherName` varchar(255) NOT NULL,
  `admissionNumber` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `classId` varchar(10) NOT NULL,
  `classArmId` varchar(10) NOT NULL,
  `dateCreated` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`Id`, `firstName`, `lastName`, `otherName`, `admissionNumber`, `password`, `classId`, `classArmId`, `dateCreated`) VALUES
(1, 'Keval', 'Patel', 'none', 'AMS005', '12345', '4', '6', '2022-10-31'),
(3, 'Ayush', 'Sukani', 'none', 'AMS007', '12345', '4', '6', '2022-10-31'),
(4, 'Bhoomin', 'Patel', 'none', 'AMS011', '12345', '4', '6', '2022-10-31'),
(5, 'Rahul', 'Patel', 'none', 'AMS012', '12345', '4', '6', '2022-10-31'),
(6, 'Kishan', 'Mistry', 'none', 'AMS015', '12345', '4', '6', '2022-10-31'),
(7, 'Akshat', 'Khalasi', 'none', 'AMS017', '12345', '4', '6', '2022-10-31'),
(8, 'Harsh', 'Parmar', 'none', 'AMS019', '12345', '4', '6', '2022-10-31'),
(9, 'Jonti', 'Patel', 'none', 'AMS021', '12345', '4', '6', '2022-10-31'),
(10, 'Kinjal', 'Dave', 'none', 'AMS110', '12345', '4', '6', '2022-10-07'),
(11, 'Prithvi', 'Show', 'none', 'AMS133', '12345', '4', '6', '2022-10-07'),
(12, 'Miguel', 'Bush', 'none', 'AMS135', '12345', '4', '6', '2022-10-07'),
(13, 'Sergio', 'Hammons', 'none', 'AMS144', '12345', '4', '6', '2022-10-07'),
(14, 'Lyn', 'Rogers', 'none', 'AMS148', '12345', '4', '6', '2022-10-07'),
(15, 'James', 'Dominick', 'none', 'AMS151', '12345', '4', '6', '2022-10-07'),
(16, 'Ethel', 'Quin', 'none', 'AMS159', '12345', '4', '6', '2022-10-07'),
(17, 'Roland', 'Estrada', 'none', 'AMS161', '12345', '4', '6', '2022-10-07');

-- --------------------------------------------------------

--
-- Table structure for table `tblterm`
--

DROP TABLE IF EXISTS `tblterm`;
CREATE TABLE IF NOT EXISTS `tblterm` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `termName` varchar(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblterm`
--

INSERT INTO `tblterm` (`Id`, `termName`) VALUES
(1, 'First'),
(2, 'Second'),
(3, 'Third');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
